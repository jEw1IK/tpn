module.exports=[32835,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_invites_%5Bid%5D_route_actions_1vqjlhm.js.map