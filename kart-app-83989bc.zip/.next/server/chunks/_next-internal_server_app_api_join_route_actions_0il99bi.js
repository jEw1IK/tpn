module.exports=[54811,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_join_route_actions_0il99bi.js.map