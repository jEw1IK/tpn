module.exports=[12615,a=>{"use strict";a.s(["default",0,function({children:a}){return a},"metadata",0,{title:"POSTNEO — калькулятор питания",description:"Энтеральное и парентеральное питание новорождённых: состав смесей, калории, белки, жиры, углеводы и баланс жидкости. Учебный прототип."}])},77456,function(a){a.n(a.i(12615))}];

//# sourceMappingURL=app_calculator_layout_tsx_1fbo82j._.js.map