module.exports=[17098,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28kart%29_patients_%5Bid%5D_edit_page_actions_06br_be.js.map