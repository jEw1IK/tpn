module.exports=[99391,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28kart%29_journal_page_actions_08i76m0.js.map