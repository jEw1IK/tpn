module.exports=[23088,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28kart%29_patients_new_page_actions_0xm1lvx.js.map