module.exports=[56847,a=>{a.v(a=>Promise.resolve().then(()=>a(86666)))}];

//# sourceMappingURL=lib_kart-client_ts_0v2v6yi._.js.map