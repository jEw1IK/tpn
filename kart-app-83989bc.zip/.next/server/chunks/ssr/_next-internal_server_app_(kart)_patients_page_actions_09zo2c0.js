module.exports=[28040,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28kart%29_patients_page_actions_09zo2c0.js.map