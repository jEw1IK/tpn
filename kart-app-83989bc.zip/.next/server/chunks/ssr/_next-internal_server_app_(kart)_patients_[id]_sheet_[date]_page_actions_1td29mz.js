module.exports=[10081,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28kart%29_patients_%5Bid%5D_sheet_%5Bdate%5D_page_actions_1td29mz.js.map