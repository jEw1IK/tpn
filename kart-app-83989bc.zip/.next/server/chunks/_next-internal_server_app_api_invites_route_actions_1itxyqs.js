module.exports=[27111,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_invites_route_actions_1itxyqs.js.map