module.exports=[92965,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_patients_%5Bid%5D_weights_route_actions_1t6z3q1.js.map