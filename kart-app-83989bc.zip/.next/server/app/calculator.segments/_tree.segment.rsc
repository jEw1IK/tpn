:HL["/_next/static/chunks/3xm0phm1g-4ms.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"calculator","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"O0AKQG-FYfvDvFmIbIxU9"}
