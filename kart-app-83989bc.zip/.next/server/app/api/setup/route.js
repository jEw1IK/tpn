var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/setup/route.js")
R.c("server/chunks/[root-of-the-server]__00ljagj._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_setup_route_actions_0txsuev.js")
R.m(83170)
module.exports=R.m(83170).exports
