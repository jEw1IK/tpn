var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/me/route.js")
R.c("server/chunks/[root-of-the-server]__09af1k7._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_me_route_actions_0j009u9.js")
R.m(21455)
module.exports=R.m(21455).exports
