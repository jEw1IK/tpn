var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0ewmhss._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_logout_route_actions_0gzx3on.js")
R.m(55778)
module.exports=R.m(55778).exports
