var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/[root-of-the-server]__0f49shs._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_users_route_actions_0mvbx1f.js")
R.m(72797)
module.exports=R.m(72797).exports
