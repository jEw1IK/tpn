var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/invites/route.js")
R.c("server/chunks/[root-of-the-server]__0rsj7g8._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_invites_route_actions_1itxyqs.js")
R.m(21832)
module.exports=R.m(21832).exports
