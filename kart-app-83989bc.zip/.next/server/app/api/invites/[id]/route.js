var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invites/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1f54436._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_invites_[id]_route_actions_1vqjlhm.js")
R.m(28500)
module.exports=R.m(28500).exports
