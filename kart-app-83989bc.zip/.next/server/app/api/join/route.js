var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/join/route.js")
R.c("server/chunks/[root-of-the-server]__1o4b2xz._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_join_route_actions_0il99bi.js")
R.m(493)
module.exports=R.m(493).exports
