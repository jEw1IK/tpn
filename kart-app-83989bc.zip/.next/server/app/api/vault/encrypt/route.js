var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/vault/encrypt/route.js")
R.c("server/chunks/[root-of-the-server]__1o3t_q-._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_vault_encrypt_route_actions_1wfr5rs.js")
R.m(24059)
module.exports=R.m(24059).exports
