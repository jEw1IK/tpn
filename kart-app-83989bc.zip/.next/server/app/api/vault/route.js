var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/vault/route.js")
R.c("server/chunks/[externals]__1vhh-4t._.js")
R.c("server/chunks/_1o2301f._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_vault_route_actions_148f0ky.js")
R.m(53114)
module.exports=R.m(53114).exports
