var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ping/route.js")
R.c("server/chunks/[root-of-the-server]__1kpdf95._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_ping_route_actions_14f35tn.js")
R.m(88551)
module.exports=R.m(88551).exports
