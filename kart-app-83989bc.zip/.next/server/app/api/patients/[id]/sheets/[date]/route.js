var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/[id]/sheets/[date]/route.js")
R.c("server/chunks/[root-of-the-server]__0f79coo._.js")
R.c("server/chunks/_0frzs49._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_[id]_sheets_[date]_route_actions_12xow5m.js")
R.m(77188)
module.exports=R.m(77188).exports
