var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0f79coo._.js")
R.c("server/chunks/_0g6s4ij._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_[id]_route_actions_1ymn1ol.js")
R.m(4186)
module.exports=R.m(4186).exports
