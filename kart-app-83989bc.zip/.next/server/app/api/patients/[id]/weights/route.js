var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/[id]/weights/route.js")
R.c("server/chunks/[root-of-the-server]__19po4x-._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_[id]_weights_route_actions_1t6z3q1.js")
R.m(33501)
module.exports=R.m(33501).exports
