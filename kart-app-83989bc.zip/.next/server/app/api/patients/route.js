var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/route.js")
R.c("server/chunks/[root-of-the-server]__0mq6z0x._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0xei_ng._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_route_actions_1sh9v8r.js")
R.m(13238)
module.exports=R.m(13238).exports
