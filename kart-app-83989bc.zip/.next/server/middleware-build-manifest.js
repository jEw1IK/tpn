globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/O0AKQG-FYfvDvFmIbIxU9/_buildManifest.js",
    "static/O0AKQG-FYfvDvFmIbIxU9/_ssgManifest.js",
    "static/O0AKQG-FYfvDvFmIbIxU9/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/1mh6a-0e61pyc.js",
    "static/chunks/3ertolydtjaa3.js",
    "static/chunks/turbopack-0flduyczoe5pk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
